
Inno Setup Script Includes (ISSI)

SHORT DESCRIPTION:
ISSI is a library of functions that can be implemented very easily into your existing setups created with Inno Setup.

Inno Setup Script Includes (c) 2003-2006 Jan Albartus
http://www.albartus.com/issi/

SYSTEM REQUIREMENTS:
Inno Setup v4.2.2 or higher and Inno Setup PreProcessor
Both available through the Inno Setup Quickstart Pack:
http://files.jrsoftware.org/ispack/

Inno Setup (c) 2006 Jordan Russell & Martijn Laan
http://www.innosetup.com/

Inno Setup Pre-Processor (c) 2006 Alex Yackimoff
http://yackimoff.net.tc/
 
[Supported 3rd Party Tools]

InfoZip / ChiefZip (c) 2006
http://www.greatchief.plus.com/chfzip26.zip

UninsHs (c) 2006 Han-soft Software
http://www.han-soft.com/uninshs.php

Download DLL (c) 2006 Bj�rnar Henden
http://www.istool.org/default.aspx/isx/isxdl

ScriptMaker (c) 2006 Jonny Kwekkeboom
http://www.hisoft2000.de/En/index.htm

Wput (c) 2006 Hagen Fritsch
http://wput.sourceforge.net/